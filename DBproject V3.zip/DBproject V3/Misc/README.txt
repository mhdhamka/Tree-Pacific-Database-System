a) Instruction to use TreePacific:
----------------------------------
   1) Open and start XAMPP and MySQL.
   2) Open the Localhost of index that consist of PHP file.
   3) Start with OptionLogin.php 
   4) Choose the client login if the user want to access the client page.
   5) To login to the client menu, user have to enter UserID and PasswordHash.
   6) Choose the staff login if the user want to access the staff page.
   7) To login to the staff menu, user have to enter UserID and PasswordHash.
   8) In the client page there will be home page, profile, and purchase showcase pages.
   9) In the staff page there will be homepage, user, companies, trees, blocks, orchards, and sales pages.
   10) All CRUD operation and report of block, orchard, and tree will be on the staff page.

b) PhpMyAdmin:
-------------------------------------
host: "localhost"
username: "root"
password: ""
databaseName: "db_g07"

c) UserID and PasswordHash for Staff
-------------------------------------
   1) UserID: 1
      PasswordHash: ahmadali

   2) UserID: 2
      PasswordHash: abubakar
      
   3) UserID: 3
      PasswordHash: azmanali

   4) UserID: 6
      PasswordHash: shahrulaminim


d) UserID and PasswordHash for Client
-------------------------------------
   1) UserID: 4
      PasswordHash: muhdfarhan

   2) USerID: 5
      PasswordHash: nuralia

